# myApp/urls.py 

from django.urls import path
from . import views

# 시작페이지 주소와 뷰 함수 연결 
urlpatterns = [
    # 주소 등록 
    # path(주소, views.뷰함수)
    path('', views.index),

    # /myApp/sub1/
    path('sub1/', views.sub1),

]