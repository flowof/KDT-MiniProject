from django.shortcuts import render
# 추가
from django.http import HttpResponse

# /, /myApp/ 주소와 연결되는 뷰함수
def index(request):
    return HttpResponse("<h1>Hello world</h1>")

# /myApp/sub1 주소와 연결되는 뷰함수
def sub1(request):
    return render(request, 'myApp/sub1.html')

