from django.shortcuts import render
# 추가
from django.http import HttpResponse

# /, /myApp/ 주소와 연결되는 뷰함수
def index(request):
    return HttpResponse("<h1>Hello world</h1>")

# /myApp/sub1 주소와 연결되는 뷰함수
def sub1(request):
    return render(request, 'myApp/sub1.html')

# /myApp/sub2 주소와 연결되는 뷰함수
def sub2(request):
    return render(request, 'myApp/sub2.html')
    
# /myApp/sub3 주소와 연결되는 뷰함수
def sub3(request):
    # 딕셔너리 형태로 전송 데이터 정의
    context = {
        'name': '공지철',
        'id' : 'YYY',
        'age' : 40,
        'grade' : [90, 85, 77]

    }
    return render(request, 'myApp/sub3.html', context)

# /myApp/sub4 주소와 연결되는 뷰함수
def sub4(request):

    # 리스트안에 튜플로 정의 => 튜플리스트 2차원
    # 4행 2열 스타일
    book_info = [
        ('title', '어린왕자'),
        ('writer', '생텍쥐페리'),
        ('price', 15000),
        ('ISBN', '483731-849-90'),
    ]

    # 5행 4열 스타일
    student_info = [
        ('홍길동', '남', '부산', 23),
        ('고길동', '남', '전주', 28),
        ('윤길동', '남', '서울', 23),
        ('박길동', '남', '마산', 23),
        ('정길순', '여', '울산', 22),
    ]

    # 딕셔너리 형태로 전송 데이타 정의 
    context = {
           'book_info': book_info, 
           'student_info' :  student_info,
           'numList' : range(1,11), # [1, 2, ... 10]
    }

    return render(request, 'myApp/sub4.html', context)

# /myApp/sub5 주소와 연결되는 뷰함수
def sub5(request):
    # 책제목과 가격으로 구성된 튜플 리스트 생성
    book_list = [
        ('파이썬 도장', 33000),
        ('C언어', 23000),
        ('JAVA', 43000),
    ]
    context = { 
                'book_list':book_list ,
            }
    return render(request, 'myApp/sub5.html', context)
    
